import React from 'react';
import VipList from './vipList';
import AppAtlas from './appAtlas';
// import AppRoutes from './comps_routes/appRoutes';

export default function AppHw() {
    return (
        <React.Fragment>
            <AppAtlas />
            {/* <VipList /> */}
        </React.Fragment>
    );
}

// export default App;